#include "Wiimote.h"
int main(){
    Wiimote mote;
    mote.Listen();
    return 0;
}